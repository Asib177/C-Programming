#include <stdio.h>

void Function1(int, int);

int main()
{
    int num1, num2;
    scanf("%d %d", &num1, &num2);
    Function1(num1, num2);

        return 0;
}

void Function1(int a, int b)
{
    int sum;
    sum = a + b;
    printf("Sum is: %d", sum);
}