#include <stdio.h>

int Function1(int, int);

int main()
{
    int num1, num2;
    scanf("%d %d", &num1, &num2);
    int flag = Function1(num1, num2);
    printf("Sum is: %d", flag);

    return 0;
}

int Function1(int a, int b)
{
    int sum;
    sum = a + b;
    return sum;
}