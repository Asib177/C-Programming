#include <stdio.h>

void Function1(int, int);
int sum;

int main()
{
    int num1, num2;
    scanf("%d %d", &num1, &num2);
    Function1(num1, num2);

    sum = num1 + num2;
    printf("\nSum in Main: %d", sum);

    return 0;
}

void Function1(int a, int b)
{
    sum = a + b;
    printf("Sum in Function: %d", sum);
}