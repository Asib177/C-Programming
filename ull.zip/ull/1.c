#include <stdio.h>

int main()
{
    int num1, num2;
    scanf("%d %d", &num1, &num2);
    int sum;
    sum = num1 + num2;
    printf("Sum is: %d", sum);

    return 0;
}