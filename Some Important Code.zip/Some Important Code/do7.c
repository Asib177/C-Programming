#include <stdio.h>
int main()
{
    int x = 10;

    do
    {
        printf("%d ", x);
        x = x + 1;

    } while (x <= 20);

    return 0;
}