#include <stdio.h>

int main()
{
    int num1, num2, choice;

    while (1)
    {
        printf("Enter two number: ");
        scanf("%d %d", &num1, &num2);
        printf("1. Add\n");
        printf("2. Subtract\n");
        printf("3. Multiply\n");
        printf("4. Divide\n");

        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            printf("Output: %d\n", num1 + num2);
            break;
        case 2:
            printf("Output: %d\n", num1 - num2);
            break;
        case 3:
            printf("Output: %d\n", num1 * num2);
            break;
        case 4:
            printf("Output: %d\n", num1 / num2);
            break;

        default:
            {printf("Wrong Choice! Choose Again.\n");
             
             
            }
            // while (1)
            // {
            //     printf("Enter two number: ");
            //     scanf("%d %d", &num1, &num2);
            //     printf("1. Add\n");
            //     printf("2. Subtract\n");
            //     printf("3. Multiply\n");
            //     printf("4. Divide\n");

            //     printf("Enter your choice: ");
            //     scanf("%d", &choice);

            //     switch (choice)
            //     {
            //     case 1:
            //         printf("Output: %d\n", num1 + num2);
            //         break;
            //     case 2:
            //         printf("Output: %d\n", num1 - num2);
            //         break;
            //     case 3:
            //         printf("Output: %d\n", num1 * num2);
            //         break;
            //     case 4:
            //         printf("Output: %d\n", num1 / num2);
            //         break;

            //     default:
            //         printf("Wrong Choice! Choose Again.\n");
            //     }
            }
        }
        return 0;
    }