/*#include <stdio.h>
int main()
{
    int n, a = 1;
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        a = a + 2;
        printf("%d ", a);
    }

    return 0;
}*/

// #include <stdio.h>

// int main()
// {
//     int n, a = 1, b = 1;
//     scanf("%d", &n);
//     for (int i = 0; i < n; i++)
//     {
//         a = a + 2;
//         printf("%d ", a);

//         for (int j = 0; j < n; j++)
//         {
//             b = b + 2;
//             printf("%d ", b);
//         }
//     }

//     return 0;
// }

#include <stdio.h>
int main()
{
    int n, b = 1;
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        b = b + 2;
        printf("%d ", b);
    }

    return 0;
}