#include <stdio.h>

void main()
{
    int i;
    i = 10;
    i = -i;
    printf("%d", i);
}