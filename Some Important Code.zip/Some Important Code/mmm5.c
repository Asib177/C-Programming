#include <stdio.h>

void main()
{
    int values,i;
    const int N =100;
    for(i=0;i<N;i++)
    {
        scanf("%d",&values[i]);
    }
    int min[]=max[0];
    // int indexmin=0;
    for(int i=1;i<N;i++){
        if(max[i]<min[i]){
            min[i]=max[i];
            // indexmin=i;
        }
    }
    printf("the min value is %d at index %d\n",min[],i);


}