#include <stdio.h>
void main()
{
    int i, sum = 0;
    int sign = 1;
    for (i = 2; i <= 6; i = i + 2)
    {
        sum = sum + sign * i;
        printf("i=%d sum=%d\n", i, sum);
        sign = -sign;
        printf("Sign: %d\n", sign);
    }
    printf("Last i when the loop is end: %d\n", i);

    printf("Final Output: %d", sum);
}