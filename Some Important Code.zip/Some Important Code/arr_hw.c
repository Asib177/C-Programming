#include <stdio.h>
//#define N = 100;

int main()
{
    int n, i;
    scanf("%d", &n);
    int arr[] = {1, 2, 3, 3, 5, 3, 1};

    for (i = 0; i < arr[7]; i++)
    {
        if (arr[i] == n)
            printf("Location/Inder: %d ", i);

        else
            printf("Doesn't Exists!!!");
    }

    return 0;
}