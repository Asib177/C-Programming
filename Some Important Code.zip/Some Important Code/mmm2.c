#include <stdio.h>
#include <math.h>

void main()
{
    double i;
    i = sqrt(25);
    printf("%f", i);
}