// #include <stdio.h>

// void main()
// {
//     FILE *file;
//     int i, sum, a = 1177;
//     int num[] = {1177, 7, 17, 7, 17};
//     file = fopen("test.txt", "w");
//     fprintf(file, "%s\n", "Hello Vaxxers!");
//     for (i = 4; i >= 0; i--)
//     {
//         fprintf(file, "%d\n", num[i]);
//     }
//     fclose(file);
// }

#include <stdio.h>
#include <string.h>

int main()
{
    int pos = 0;
    char string[50];
    char id[50] = "011221125";

    gets(string);

    for (pos = 0; pos < strlen(string); pos++)
    {
        if (pos == 0)
            string[pos] = toupper(string[pos]);
        if (string[pos] == ' ')
            string[pos + 1] = toupper(string[pos + 1]);
    }
    string[strlen(string)] = " ";

    printf(strcat(string, id));
}