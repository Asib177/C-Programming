#include <stdio.h>
void function();

void main()
{
    int n1, n2;
    printf("Input 1st number: ");
    scanf("%d", &n1);
    printf("Input 2nd number: ");
    scanf("%d", &n2);
    printf("Expected Output:\n");
    printf("Before swaping n1=%d, n2=%d", n1, n2);
    function(n1, n2);
}

void function(int n1, int n2)
{
    int temp;
    temp = n1;
    n1 = n2;
    n2 = temp;
    printf(" After swaping n1=%d, n2=%d", n1, n2);
}