#include <stdio.h>
void Function();
void main()
{
    int n;
    scanf("%d", &n);

    Function(n);
}

void Function(int n)
{
    if (n % 2 == 0)
        printf("The number is even");
    else
        printf("The number is odd");
}