#include <stdio.h>
int armstrongNumber();
int perfectNumber();

int main()
{
    int n;
    printf("Input any number: ");
    scanf("%d", &n);
    // printf("n = %d\n", n);
    printf("Expected Output :\n");
    int flag = armstrongNumber(n);
    if (flag == 1)
        printf("The %d is an Armstrong number.", n);
    else
        printf("The %d is not an Armstrong number.", n);
    int value = perfectNumber(n);
    if (value == 1)
        printf("The %d is an Perfect number.", n);
    else
        printf("The %d is not an Perfect number.", n);
    return 0;
}

int armstrongNumber(int n)
{
    int temp = n, sum = 0;
    // printf("temp = %d\n", temp);

    while (temp != 0)
    {
        int r = temp % 10;
        sum = sum + r * r * r;
        temp = temp / 10;
    }
    // printf("Sum = %d\n", sum);
    // if (sum == n)
    //     printf("Armstrong Number");
    // else
    //     printf("Not Armstrong Number");
    if (sum == n)
        // printf("Expected Output :\nThe %d is an Armstrong number.", n);
        return 1;
    else
        return -1;
}
int perfectNumber(int n)
{
    int num = n, i, result = 0;
    for (i = 1; i <= num; i++)
    {
        if (num % i == 0)
            result += i;
    }
    // if (result == 2 * num)
    //     printf("The %d is a Perfect number.");
    // else
    //     printf("The %d is not a Perfect number.");
    if (result == 2 * num)
        return 1;
    else
        return -1;
}