#include <stdio.h>
void squreFunction(int n);
int main()
{
    int n;
    printf("Input any number for square: ");
    scanf("%d", &n);

    double c = squareFunction(n);
    printf("Enpected Output: %.2lf", c);
    return 0;
}

void squareFunction(int n)
{
    double r = n * n;
    return r;
    // return (n * n);
}