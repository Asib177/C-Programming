#include <stdio.h>
#define size 100
void Function();
void main()
{
    int n;
    scanf("%d", &n);

    Function(n);
}

void Function(int n)
{
    int arr[size], i;
    for (i = 0; i < n; i++)
    {
        printf("element - %d:", i);
        scanf("%d", &arr[i]);
    }

    int max = arr[0];
    for (i = 0; i < n; i++)
    {
        if (arr[i] >= max)
            max = arr[i];
    }
    printf("Expected Output :\nThe largest element in the array is : %d", max);
}