#include <stdio.h>
void perfectNumber(int,int);

int main()
{
    int n1, n2;
    printf("Input lowest search limit of perfect numbers : ");
    scanf("%d", &n1);
    printf("Input highest search limit of perfect numbers : ");
    scanf("%d", &n2);

    printf("Expected Output :\n");
    perfectNumber(n1,n2);

    return 0;
}

void perfectNumber(int n1, int n2)
{
    int i,j, result = 0;
    printf("The perfect numbers between %d to %d are : ", n1, n2);
    for (i = n1; i <= n2; i++)
    {
      for (j = 1; j <= i; j++)
      {
        if (i % j == 0)
            result += j;

      }
       if (result == 2 * i)
       printf("%d ", i);
       result = 0;
    }
}
