#include <stdio.h>

void main()
{
    int n, i, j, sum1 = 1, sum2 = 0;
    scanf("%d", &n);
    int arr[100][100];

    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            scanf("%d", &arr[i][j]);
        }
    }

    int isUpper = 1;
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            if (j < i && arr[i][j] != 0)
            {
                isUpper = 0;
            }
        }
    }
    if (isUpper == 1)
    {
        for (i = 0; i < n; i++)
        {
            for (j = 0; j < n; j++)
            {
                if (i == j)
                    sum1 *= arr[i][j];
            }
        }
        printf("%d", sum1);
    }
    if (isUpper == 0)
    {
        for (i = 0; i < n; i++)
        {
            for (j = 0; j < n; j++)
            {
                if (i == j)
                    sum2 += arr[i][j];
            }
        }
        printf("%d", sum2);
    }
}
