// #include <stdio.h>

// void main()
// {
//     int n, i, r = 5, l = 1;
//     scanf("%d", &n);
//     float sum = 0;
//     int fact = 1;

//     for (i = 1; i <= n; i++)
//     {
//         r = r * 2;
//         printf("%d ",r);
//         // for (int j = 1; j <= n; j++)
//         // {
//         //     fact += fact * j;
//         // }
//         // sum += r / fact;
//     }
//     // printf("Sum = %.3f", sum);
// }
////////////////////////////////////
////////////////////////////////

#include <stdio.h>

void main()
{
    int n, i = 0, r = 5;
    scanf("%d", &n);

    printf("%d", r);
    while (r < n)
    {
        r = r * 2;
        if (r < n)
            printf(",%d", r);
        i++;
    }
}