#include <stdio.h>
void main()
{
    int M = 2, N = 3;
    int scores[20][20];

    for (int i = 0; i < M; i++)
    {
        for (int j = 0; j < N; j++)
        {
            scanf("%d", &scores[i][j]);
        }
        printf("\n");
    }

    for (int i = 0; i < M; i++)
    {
        for (int j = 0; j < N; j++)
        {
            printf("%d ", scores[i][j]);
        }
        printf("\n");
    }
}