#include <stdio.h>

int main()
{
    int i, n, j, sum = 0, arr[100][100];
    scanf("%d", &n);

    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            scanf("%d", &arr[i][j]);
        }
    }

    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            // if (i == (n + 1) / 2 || j == (n + 1) / 2 || (i == 0 && j == (n + 1) / 2) ||
            //     (j == (n - 1) && i == (n + 1) / 2) ||
            //     (j == (n + 1) / 2 && i == n) || (j == 0 && i == (n + 1) / 2))
            // if (i == (n - 1) / 2)
            // if (i == 0 && j == (n + 1) / 2)
            if (i == (n - 1) / 2 || j == (n - 1) / 2)
                sum += arr[i][j];
        }
    }
    printf("%d", sum);

    return 0;
}