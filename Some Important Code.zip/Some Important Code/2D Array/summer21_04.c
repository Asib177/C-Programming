#include <stdio.h>

int main()
{
    int b = 0;
    // int a[5] = {b + 1, b + 2, b + 3, b + 4, b + 5};
    // int a[5]={}
    // for (int i = 0; i < 5; i++)
    // {
    //     printf("%d ", a[i]);
    // }
    int a[5] = {1, 2, 3, 4, 5};
    int *p1, t, u, v, w, x;

    p1 = a;
    // printf("%d\n", p1);

    t = (*p1)++;
    // printf("t= %d\n", t);

    u = *p1;
    // printf("u= %d\n", u);

    v = *(++p1);
    // printf("v= %d\n", v);

    // w = *(p1++);
    // printf("w= %d\n", w);

    w = *(++p1);
    // printf("w= %d\n", w);

    // x = *(++p1);
    // printf("x= %d\n", x);

    printf("%d %d %d %d", t, u, v, w);

    return 0;
}