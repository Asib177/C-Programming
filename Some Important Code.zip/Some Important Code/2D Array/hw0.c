#include <stdio.h>

void main()
{
    int n, i, j;
    scanf("%d", &n);
    int arr[20][20];

    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            scanf("%d", &arr[i][j]);
        }
    }
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            if (i == j || i + j == n - 1)
                printf("%d ", arr[i][j]);
            else
                printf("_ ");
        }
        printf("\n");
    }
}