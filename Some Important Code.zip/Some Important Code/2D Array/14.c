#include <stdio.h>

void main()
{
    int i, j, n, count = 0;
    scanf("%d", &n);
    int arr[20][20];

    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            scanf("%d", &arr[i][j]);
        }
    }

    int arrA[20][20];
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            arrA[i][j] = arr[i][j];
        }
    }

    int arrB[20][20];
    for (j = 0; j < n; j++)
    {
        for (i = 0; i < n; i++)
        {
            arrB[i][j] = arr[i][j];
        }
    }

    for (j = 0; j < n; j++)
    {
        for (i = 0; i < n; i++)
        {
            if (arrA[i][j] != arrB[i][j])
            {
                count++;
            }
        }
    }
    printf("%d", count);
    if (count == 0)
        printf("Yes");
    else
        printf("No");
}