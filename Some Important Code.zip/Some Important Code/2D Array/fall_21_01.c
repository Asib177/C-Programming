#include <stdio.h>
int a = 0, b = 0, c = 0;
int func1(int x);
void func2(int *x, int y);
int func3(int x, int *y);

void main()
{
    int a = 2;
    func3(a, &b);
    b = func1(a);
    // printf("b=%d", b);
    func2(&a, b);
}

int func1(int p)
{
    // printf("p=%d", p);
    // printf("a=%d", a);
    c = p + a;
    // printf("c=%d", c);
    func2(&a, b);
    // printf("m=%d", m);
    return c;
}

void func2(int *x, int b)
{
    // printf("*X=%d\n", *x);
    // printf("b=%d\n", b);
    // printf("*X=%d\n", *x);
    *x *= 2;
    // printf("*X=%d\n", *x);
    b = func3(a, x);
    // printf("b=%d", b);
}

int func3(int c, int *n)
{
    // printf("c=%d *n=%d", c, *n);
    c = 2;
    // c = ++(*n) * *n;
    // printf("Css=%d", c);
    return ++(*n) * *n;
}
