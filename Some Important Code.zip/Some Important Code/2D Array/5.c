#include <stdio.h>

void main()
{
    int i, j, n;
    scanf("%d", &n);
    int arr[20][20];

    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            scanf("%d", &arr[i][j]);
        }
    }

    printf("\nMajor diagonal: ");
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            if (i == j)
                printf("%d ", arr[i][j]);
        }
    }
    printf("\nMinor diagonal: ");
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            if ((i + j) == (n - 1))
                printf("%d ", arr[i][j]);
        }
    }
}