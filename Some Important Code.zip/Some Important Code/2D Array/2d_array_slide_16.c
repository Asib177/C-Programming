#include <stdio.h>

int main()
{
    int n, m, i, j;
    scanf("%d %d", &n, &m);
    int arr[100][100];

    for (i = 0; i < n; i++)
    {
        for (j = 0; j < m; j++)
        {
            scanf("%d", &arr[i][j]);
        }
    }
    int flag = 0;
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < m; j++)
        {
            if (i + 1 == j + 1)
                flag = 1;
            // printf("%d ", arr[i][j]);
        }
        // printf("\n");
    }
    if (flag == 1)
        printf("Toepliz!");
    else
        printf("Not Toepliz!");

    return 0;
}