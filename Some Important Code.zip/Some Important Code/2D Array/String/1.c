#include <stdio.h>
#define size 100

void main()
{
    char str[size];
    gets(str);
    int i, lenth = 0;
    for (i = 0; str[i] != '\0'; i++)
    {
        lenth++;
    }
    printf("%d", lenth);
}