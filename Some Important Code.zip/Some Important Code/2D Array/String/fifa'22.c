#include <stdio.h>

void main()
{
    int m, n = 4, sum = 0;
    scanf("%d", &m);
    float avg;
    int info[1000][1000];

    printf("Input eatch of the 32 countries number of Matches,Losts,Drows,Golls:\n");
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            scanf("%d", &info[i][j]);
        }
    }

    printf("\nAverage number of Golls score:\n");
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (j == n)
                sum += info[i][j];
        }
    }

    avg = (float)sum / m;
    printf("%d\n", avg);

    printf("The information of those countries that score more than the average numbers of golls:\n");
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (info[i][j] > avg)
                printf("%d ", info[i][j]);
        }
    }
}