#include <stdio.h>
#define N 1000
void takeOneRoadInfoFormKeyboard();
int displayAllRoadsInfoReverse();

struct Road_Structure
{
    char road_name[N];
    int lanes;
    float road_length;
    float average;
};

int main()
{
    struct Road_Structure arr[N];
    int n, i;
    takeOneRoadInfoFormKeyboard(arr[]);

    return 0;
}

void takeOneRoadInfoFormKeyboard(int arr[])
{
    gets(arr[].road_name);
    scanf("%d", &arr[].lanes);
    scanf("%f", &arr[].road_length);
    scanf("%f", &arr[].average);
    // displayAllRoadsInfoReverse(arr[]);
}

// int displayAllRoadsInfoReverse(int arr[])
// {
//     printf("%s", arr[0].road_name);
// }