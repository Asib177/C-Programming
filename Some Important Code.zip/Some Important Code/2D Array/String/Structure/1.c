#include <stdio.h>

// struct Point
// {
//     int x, y;
// };
// void main()
// {
//     struct Point p1 = {0, 1};
//     // Accesing members of point p1
//     p1.x = 20;
//     printf("x = %d, y = %d", p1.x, p1.y);
// }

// struct Point
// {
//     int x, y, z;
// };
// void main()
// {
//     // Create an Array of Structures
//     struct Point arr[10];
//     // Access Array members
//     arr[0].x = 10;
//     arr[0].y = 20;
//     printf("%d , %d", arr[0].x, arr[0].y);
// }

struct myStructure
{
    char name;
    int id;
    float cgpa;
};

int main()
{
    struct myStructure s1;

    s1.name = "Asib";
    s1.id = 011221177;
    s1.cgpa = 3.67;

    printf("%s\n", s1.name);
    printf("%d\n", s1.id);
    printf("%f\n", s1.cgpa);

    return 0;
}