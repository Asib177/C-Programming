#include <stdio.h>

int main()
{
    char str[100];
    gets(str);

    for (int i = 0; str[i] != '\0'; i++)
    {
        printf("%c", (str[i] + ('a' || 'A')));
    }
}