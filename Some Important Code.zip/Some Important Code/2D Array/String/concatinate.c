#include <stdio.h>
#define size 100

int main()
{
    char str1[size], str2[size];
    gets(str1);
    gets(str2);

    int i, j, len = 0;
    for (i = 0; str1[i] != '\0'; i++)
    {
        len++;
    }

    for (j = 0; str2[j] != '\0'; j++)
    {
        str1[len + j] = str2[j];
    }
    str1[len + j] = '\0';
    printf("%s", str1);

    return 0;
}
