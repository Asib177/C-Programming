#include <stdio.h>
// function that will count the average
float average(int arr[], int n)
{
    float sum = 0, avg;
    for (int i = 0; i < n; i++)
    {
        sum = sum + arr[i];
    }
    avg = sum / n;
    return avg;
}

int main()
{

    int n = 0, N = 100000;
    int numOfVahicle[N];
    char choice;
    while (1)
    {
        // printing the menu
        printf("Enter 'a', to take number of motor vehicles travel on a (one) road.\n");
        printf("Enter 'b', to find the average number of motor vehicles travel over all the roads.\n");
        printf("Enter 'c', to count and display the Number of roads which have above average number of motor vehicles.\n");
        printf("Enter 'q', to quit/exit the menu system.\n");
        fflush(stdin);

        scanf("%c", &choice);

        if (choice == 'q')
            break;
        switch (choice)
        {
        case 'a':
        {
            printf("How many Vahicle travels the road : ");
            int num;
            scanf("%d", &num);
            numOfVahicle[n++] = num;
            break;
        }
        case 'b':
        {
            // here n represent the size of the numOfVahicle array
            // through n we can find out
            if (n == 0)
            {
                printf("No motor vehicles information is found. Please populate motor vehicles information first.\n");
                break;
            }
            else
            {
                // passing the number of vahicle array to find out the average vahicle
                float averageVahicle = average(numOfVahicle, n);
                printf("the average number of motor vehicles travel over all the roads is : %f \n", averageVahicle);
            }

            break;
        }
        case 'c':
        {
            // here n represent the size of the numOfVahicle array
            // through n we can find out
            if (n == 0)
            {
                printf("No motor vehicles information is found. Please populate motor vehicles information first \n");
                break;
            }
            else
            {
                int count = 0;
                float averageVahicle = average(numOfVahicle, n);
                for (int i = 0; i < n; i++)
                {
                    if (averageVahicle < numOfVahicle[i])
                        count++;
                }
                printf("the number of roads which have above average number of motor vehicles : %d \n", count);
            }

            break;
        }
        default:
        {
            printf("Invalid Input.Try again.");
            break;
        }
        }
        printf("\n\n");
    }
}