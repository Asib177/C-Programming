#include <stdio.h>
#include <stdlib.h>
#define N 100

void main()
{
    int n, i, sum = 0, count = 0;
    float avg;
    char choice;
    int numOfVehicles[N];
    while (choice != 'q')
    {
        getchar();
        printf("Enter your choice(alphabet):");
        scanf("%c", &choice);
        switch (choice)
        {
        case 'a':
            printf("Enter the number of roads: ");
            scanf("%d", &n);
            printf("Travelling vehicles numbers input:\n");
            for (i = 0; i < n; i++)
            {
                scanf("%d", &numOfVehicles[i]);
            }
            break;
        case 'b':
            for (i = 0; i < n; i++)
            {
                sum += numOfVehicles[i];
                avg = (float)sum / n;
            }
            printf("Sum is: %d\n", sum);
            printf("Avg is: %f\n", avg);
            break;
        case 'c':
            printf("Display roads which have above average:\n");
            for (i = 0; i < n; i++)
            {
                if (numOfVehicles[i] > avg)
                {
                    count++;
                    printf("%d ", numOfVehicles[i]);
                }
            }
            printf("Count is: %d\n", count);
            break;
        case 'q':
            exit(1);
            break;
        default:
            printf("Invalid Input.\n");
        }
    }
}