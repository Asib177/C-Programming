#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main()
{
    char arr[5][30] = {"Hello World!",
                       "Good morning.",
                       "UIU is the Best!",
                       "Are you a programmer?",
                       "Be a problem solver."};

    char str1[50], str2[50];
    int a = 2;
    int b = 1;
    int c = 1;
    strcpy(str1, arr[a]);
    // printf("%s", str1);
    strcpy(str2, arr[(a + 2) % 5]);
    // printf("%s", str2);
    if (strcmp(str1, str2) > 0)
    {
        str1[b] = toupper(str1[c]);
        // printf("%s", str1);
    }
    else
    {
        str2[b] = toupper(str2[c]);
        // printf("%s", str2);
    }

    strncpy(str2, arr[c], a);
    // printf("%s", str2);
    strcat(str1, str2);
    puts(str1);

    return 0;
}