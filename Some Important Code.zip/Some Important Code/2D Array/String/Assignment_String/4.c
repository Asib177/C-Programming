#include <stdio.h>

int main()
{
    char ch, str[100];
    gets(str);
    int i, word = 1;

    for (i = 0; str[i] != '\0'; i++)
    {
        if (str[i] == ' ' || str[i] == '\t' || str[i] == '\n')
            word++;
    }
    printf("%d", word);

    return 0;
}