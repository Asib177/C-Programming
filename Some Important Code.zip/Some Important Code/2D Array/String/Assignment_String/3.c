#include <stdio.h>

int main()
{
    char ch, str[100];
    gets(str);
    int i, vowels = 0;

    for (i = 0; (ch = str[i]) != '\0'; i++)
    {
        if ((ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') ||
            (ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U'))
            vowels++;
    }
    printf("%d", vowels);

    return 0;
}
