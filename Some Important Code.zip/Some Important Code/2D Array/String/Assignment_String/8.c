#include <stdio.h>
#define size 100
int main()
{
    char str[size];
    gets(str);
    int i, j, temp;

    for (i = 0; str[i] != '\0'; i++)
    {
        for (j = 0; str[j] != '\0'; j++)
        {
            if (str[i] < str[j])
            {
                temp = str[i];
                str[i] = str[j];
                str[j] = temp;
            }
        }
    }

    printf("%s", str);

    return 0;
}
