#include <stdio.h>
#define size 100

int main()
{
    char str1[size];
    char str2[size];

    gets(str1);
    gets(str2);

    int i, j, lenth = 0;

    for (i = 0; str1[i] != '\0'; i++)
    {
        lenth++;
    }

    for (j = 0; str2[j] != '\0'; j++)
    {
        str1[lenth + j] = str2[j];
    }
    str1[lenth + j] = '\0';

    printf("%s", str1);

    return 0;
}