#include <stdio.h>
#define size 100
int main()
{
    char str1[size], str2[size];
    gets(str1);
    int i, j, len = 0;

    for (i = 0; str1[i] != '\0'; i++)
    {
        len++;
    }
    for (j = 0, i = len - 1; i >= 0; i--, j++)
    {
        str2[j] = str1[i];
    }
    str2[j] != '\0';

    if (str1[i] == str2[j])
        printf("Palindrom");
    else
        printf("Not Palindrom");

    return 0;
}
