#include <stdio.h>
#define size 100
int main()
{
    char str[size], input;
    gets(str);
    scanf("%c", &input);
    // input = getchar();
    int i, count = 0;

    for (i = 0; str[i] != '\0'; i++)
    {
        if (str[i] == input)
        {
            count++;
        }
    }
    printf("%d", count);

    return 0;
}
