#include <stdio.h>
#define size 100

void main()
{
    char str[size];
    char str1[size];
    gets(str);
    gets(str1);


    char Concatenated[size];
    for(int i=0;)

}