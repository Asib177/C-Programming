#include <stdio.h>
#define size 100

void main()
{
    char str[size];
    char str1[size];
    int i;

    gets(str);
    for (i = 0; str[i] != '\0'; i++)
    {
        str1[i] = str[i];
    }
    str1[i] = '\0';
    printf("%s", str1);
}