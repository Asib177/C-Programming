#include <stdio.h>

int main()
{
    int n, i, j, arr[100][100], temp;
    scanf("%d", &n);

    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            scanf("%d", &arr[i][j]);
        }
    }

    for (i = 0; i < n; i++)
    {
        // if (i == j)
        //     arr[i][j] = arr[i][(n - 1) - i];
        j = i;
        // printf("%d ", j);
        temp = arr[i][j];
        arr[i][j] = arr[i][(n - j) - 1];
        arr[i][(n - j) - 1] = temp;
    }

    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            printf("%d ", arr[i][j]);
            // if (i == j)
            //     printf("%d ", arr[i][(n - 1) - i]);
        }
        printf("\n");
    }
    return 0;
}