#include <stdio.h>

void main()
{
    int i, j, m, sum = 0;
    printf("Enter any odd number: ");
    scanf("%d", &m);
    int arr[20][20];

    for (i = 0; i < m; i++)
    {
        for (j = 0; j < m; j++)
        {
            scanf("%d", &arr[i][j]);
        }
    }

    for (i = 0; i < m; i++)
    {
        for (j = 0; j < m; j++)
        {
            if (i == 0 || i == m - 1 || i + j == m - 1 || i == j)
            {
                sum += arr[i][j];
            }
        }
    }
    printf("%d ", sum);
}