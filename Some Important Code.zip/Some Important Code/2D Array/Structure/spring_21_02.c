#include <stdio.h>
#include <string.h>
void main()
{
    int a = 6;
    char str1[50] = "011221177";
    // printf("%s", str1);
    char arr[4][20] = {"is truthful",
                       "is honest",
                       "is friendly",
                       "is brave",
                       "is trustworthy",
                       "is straightforward",
                       "is simple",
                       "is dependable"};

    // for (int i = 0; i < 4; i++)
    // {
    //     for (int j = 0; j < 20; j++)
    //     {
    //         printf("%c", arr[i][j]);
    //     }
    // }
    strcat(str1, " ");
    // printf("%s", str1);
    strcat(str1, arr[a]);
    // printf("%s", str1);
    strcpy(str1, strstr(str1, "s "));
    // printf("%s", str1);
}