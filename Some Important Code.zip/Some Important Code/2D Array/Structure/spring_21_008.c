#include <stdio.h>
#include <string.h>

int main()
{
    char str[50];
    gets(str);
    int i, len = 0;
    // int d = strlen(str);
    // printf("%d", d);
    for (i = 0; str[i] != '\0'; i++)
    {
        len++;
    }
    printf("%d", len);
    if (len % 2 != 0)
        printf("\nRakibul Asib Redoy");
    else if (len % 2 == 0)
        printf("\n011221177");
    // if (d % 2 != 0)
    //     printf("Rakibul Asib Redoy");
    // else if (d % 2 == 0)
    //     printf("011221177");
    return 0;
}