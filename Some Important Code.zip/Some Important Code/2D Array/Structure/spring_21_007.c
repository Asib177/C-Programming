#include <stdio.h>
struct Soldier takeInput(struct Soldier s);

struct Soldier
{
    char id[20];
    int age;
    float weight;
};

int main()
{
    struct Soldier soldier1;
    struct Soldier p = takeInput(soldier1);
    printf("ID: %s\nAge: %d\nWeight: %.2f\n", p.id, p.age, p.weight);
    return 0;
}

struct Soldier takeInput(struct Soldier s)
{
    gets(s.id);
    scanf("%d %f", &s.age, &s.weight);
    // printf("%s %d %.2f", s.id, s.age, s.weight);

    return s;
}

/*#include <stdio.h>

struct Soldier takeInput(struct Soldier s);

struct Soldier
{
    char id[20];
    int age;
    float weight;
};

int main()
{
    struct Soldier soldier1;
    struct Soldier p = takeInput(soldier1);
    printf("%s %d %f", p.id, p.age, p.weight);
    return 0;
}

struct Soldier takeInput(struct Soldier s)
{
    gets(s.id);
    scanf("%d %f", &s.age, &s.weight);
    // printf("%s %d %.2f", s.id, s.age, s.weight);

    return s;
}*/