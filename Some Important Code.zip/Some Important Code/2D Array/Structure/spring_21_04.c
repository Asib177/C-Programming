#include <stdio.h>
void main()
{
    int a = 1;
    int num[10], sum = 0;
    for (int i = 0; i < 10; i++)
    {
        num[i] = 3 * i + a;
        // printf("%d ", num[i]);
    }
    for (int i = 0; i < 10; i++)
    {
        if (i % 3 == 0)
        {
            printf("\n%d\n", *(num + i));
        }
        sum += *(num + i);
    }
    // printf("%d\n", sum);
    sum /= 10;
    printf("%d\n", sum);
}