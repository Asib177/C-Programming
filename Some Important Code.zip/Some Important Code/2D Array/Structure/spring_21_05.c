#include <stdio.h>
int sumOfServens(int *);

int main()
{
    int i, scores[5];
    for (i = 0; i < 5; i++)
    {
        scores[i] = 7 + 2 * i;
        // printf("%d ", scores[i]);
    }
    int p = sumOfServens(&scores);
    printf("%d", p);

    return 0;
}

int sumOfServens(int *arr)
{
    int i, sum = 0;
    // for (i = 0; i < 5; i++)
    // {
    //     // scores[i] = 7 + 2 * i;
    //     printf("\n%d ", *(arr + i));
    // }
    for (i = 0; i < 5; i++)
    {

        if (*(arr + i) % 7 == 0)
            sum += *(arr + i);
        // printf("%d ", *(arr + i));
    }
    return sum;
}