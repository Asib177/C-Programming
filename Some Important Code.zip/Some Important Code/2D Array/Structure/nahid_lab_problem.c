#include <stdio.h>
struct student print_student(struct student s);

struct student
{
    char name[50];
    int id;
    float CGPA;
} arr[5];

int main()
{
    for (int i = 0; i < 5; i++)
    {
        fflush(stdin);
        printf("Enter student%d name: ", i + 1);
        gets(arr[i].name);
        printf("Enter student%d id: ", i + 1);
        scanf("%d", &arr[i].id);
        printf("Enter student%d cgpa: ", i + 1);
        scanf("%f", &arr[i].CGPA);
    }
    print_student(arr[5]);

    return 0;
}

struct student print_student(struct student s)
{
    for (int i = 0; i < 5; i++)
    {
        printf("%s\n%d\n%.2f\n", s.name, s.id, s.CGPA);
    }
}