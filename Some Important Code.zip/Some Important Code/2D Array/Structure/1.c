// // Write a C program to Store Information in Structure and Display it

// #include <stdio.h>
// void function();

// struct Information
// {
//     char name[50];
//     int id;
//     float cgpa;
// };
// struct Information p1;

// int main()
// {
//     function();

//     return 0;
// }

// void function()
// {
//     gets(p1.name);
//     scanf("%d", &p1.id);
//     scanf("%f", &p1.cgpa);

//     printf("\n\n%s\n", p1.name);
//     printf("%d\n", p1.id);
//     printf("%.2f", p1.cgpa);
// }
/////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////

// Write a C program to Store Information in Structure and Display it

#include <stdio.h>
void function();

struct Information
{
    char name[50];
    int id;
    float cgpa;
};
struct Information arr[50];

int main()
{
    struct Information arr[50];
    // int n;
    // scanf("%d", &n);
    function();

    return 0;
}

void function()
{
    int n;
    scanf("%d", &n);
    // getchar();
    for (int i = 0; i < n; i++)
    {
        fflush(stdin);
        gets(arr[i].name);
        scanf("%d", &arr[i].id);
        scanf("%f", &arr[i].cgpa);
    }

    for (int i = 0; i < n; i++)
    {
        printf("\n\n%s\n", arr[i].name);
        printf("%d\n", arr[i].id);
        printf("%.2f", arr[i].cgpa);
    }
}