#include <stdio.h>
void main()
{
    int sum = 0, a = 5, num[4];
    FILE *fp = fopen("input.txt", "w");
    fprintf(fp, "%s\n", "Good Morning");
    // fscanf(fp, "%s\n", "Good Morning");
    for (int i = 0; i < 5; i++)
    {
        num[i] = 2 * i + a;
    }
    for (int i = 0; i < 4; i++)
    {
        sum += num[i];
        fprintf(fp, "%d\n", num[i]);
    }
    fprintf(fp, "%d", sum);
    fclose(fp);

    // FILE *fp;
    // int myInt = 5;
    // fp = fopen("Output.txt", "w"); // "w" means that we are going to write on this file
    // fprintf(fp, "This is being written in the file. This is an int variable: %d", myInt);
    // fclose(fp);
}
