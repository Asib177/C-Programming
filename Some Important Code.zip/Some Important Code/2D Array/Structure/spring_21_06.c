#include <stdio.h>
#include <string.h>
#define MAX 100

int main()
{
    char str[MAX] = {0};
    int i;

    printf("Enter a string: ");
    scanf("%[^\n]s", str);

    char id;
    printf("Enter your id: ");
    gets(id);

    for (i = 0; str[i] != '\0'; i++)
    {

        if (i == 0)
        {
            if ((str[i] >= 'a' && str[i] <= 'z'))
                str[i] = str[i] - 32; // subtract 32 to make it capital
            continue;                 // continue to the loop
        }
        if (str[i] == ' ') // check space
        {

            ++i;
            // check next character is lowercase alphabet
            if (str[i] >= 'a' && str[i] <= 'z')
            {
                str[i] = str[i] - 32; // subtract 32 to make it capital
                continue;             // continue to the loop
            }
        }
        else
        {

            if (str[i] >= 'A' && str[i] <= 'Z')
                str[i] = str[i] + 32;
        }
    }
    // printf("Capitalize string is: %s\n", str);

    strcat(str, "id");
    printf("Concatate string is: %s\n", str);

    return 0;
}