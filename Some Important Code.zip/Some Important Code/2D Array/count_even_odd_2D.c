#include <stdio.h>

void main()
{
    int m, n, i, j, even = 0, odd = 0;
    scanf("%d %d", &m, &n);

    int arr[20][20];
    for (i = 0; i < m; i++)
    {
        for (j = 0; j < n; j++)
        {
            scanf("%d", &arr[i][j]);
        }
    }

    for (i = 0; i < m; i++)
    {
        for (j = 0; j < n; j++)
        {
            if (arr[i][j] % 2 == 0)
                even++;
            else
                odd++;
        }
    }
    printf("Even is: %d\nOdd is: %d", even, odd);
}