#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main()
{
    char arr[5][20] = {"Elon Musk", "Sundar Pichai", "Steve Wozniak", "Steve Jobs", "Mark Zuckerberg"};
    char my_str[50], temp_str[50];

    // for (int i = 0; i < 5; i++)
    // {
    //     for (int j = 0; j < 20; j++)
    //     {
    //         printf("%c", arr[i][j]);
    //     }
    // }

    int a = 3, b = 1, c = 2;
    strcpy(my_str, arr[a]);
    printf("%s\n", my_str);
    my_str[b] = toupper(my_str[c]);
    printf("%c\n", my_str[b]);
    printf("%s\n", my_str);

    strncpy(temp_str, arr[b], c);
    printf("%s\n", temp_str);

    strcat(my_str, temp_str);
    printf("%s\n", my_str);

    return 0;
}