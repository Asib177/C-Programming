#include <stdio.h>
int a, c;
float b;
int func1(float x);
void func2(int *x, float y);

void main()
{
    a = 7;
    b = func1(a);
    printf("b: %.2f\n", b);
    // printf("a: %d\n", a);

    func2(&a, b);
}

int func1(float x)
{
    printf("X: %.2f\n", x);
    printf("a: %d\n", a);

    c = x + a;
    printf("c: %d\n", c);

    func2(&c, b);
    return c;
}

void func2(int *x, float y)
{
    printf("a: %d\n", a);

    printf("*X: %d\n", *x);
    printf("y: %.2f\n", y);
    printf("a: %d\n", a);

    *x *= 2;
    printf("*X: %d\n", *x);

    printf("a: %d\n", a);
    y = a;
    printf("y: %.2f\n", y);
}