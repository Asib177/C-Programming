#include <stdio.h>

int main()
{
    int m, n, i, j;
    int arr2[20][20];
    scanf("%d %d", &m, &n);

    for (i = 0; i < m; i++)
    {
        for (j = 0; j < n; j++)
        {
            scanf("%d", &arr2[i][j]);
        }
    }

    printf("Row-wise: ");
    for (i = 0; i < m; i++)
    {
        for (j = 0; j < n; j++)
        {
            printf("%d ", arr2[i][j]);
        }
    }

    printf("\nColumn-wise: ");
    for (j = 0; j < n; j++)
    {
        for (i = 0; i < m; i++)
        {
            printf("%d ", arr2[i][j]);
        }
    }
    return 0;
}