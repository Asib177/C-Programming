#include <stdio.h>
#include <string.h>
#include <ctype.h>
int main()
{
    int i, j, n;
    // int A[3][3] = {10, 20, 30, 40, 50, 60, 70, 80, 90};
    // for (i = 0; i < 3; i++)
    // {
    //     for (j = 0; j < 3; j++)
    //     {
    //         if (i == j)
    //         {
    //             printf("%d\n", A[j][i]);
    //         }
    //     }
    // }
    // int arr[100][100];
    // scanf("%d", &n);
    // for (i = 0; i < n; i++)
    // {
    //     for (j = 0; j < n; j++)
    //     {
    //         scanf("%d", &arr[i][j]);
    //     }
    // }
    // for (i = n - 1; i >= 0; i--)
    // {
    //     for (j = 0; j < n; j++)
    //     {
    //         printf("%d ", arr[i][j]);
    //     }
    //     printf("\n");
    // }
    // char str1[100] = "Hello";
    // char str2[100] = "Bonjour";
    // int i, k;
    // strcat(str1, "Maria");
    // puts(str1);
    // printf("\n");
    // strcpy(str2, "Federick");
    // puts(str2);
    // printf("\n");
    // i = strlen(str1);
    // printf("%d\n", i);
    // for (k = 0; str2[k] != '\0'; k++)
    //     str1[i + k] = str2[k];
    // puts(str1);
    // printf("\n");
    // puts(str2);
    // printf("\n");
    // puts(str1);
    // printf("\n");
    // strrev(str1);
    // puts(str1);

    char str[100];
    gets(str);

    for (i = 0; str[i] != '\0'; i++)
    {
        if (str[i] >= 'a' && str[i] <= 'z')
            str[i] -= 32;
        else if (str[i] >= 'A' && str[i] <= 'Z')
            str[i] += 32;
    }
    // str[i] != '\0';
    // puts(str);
    printf("%s", str);
    return 0;
}
