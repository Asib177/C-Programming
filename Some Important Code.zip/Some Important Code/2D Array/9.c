#include <stdio.h>

void main()
{
    int i, j, m, n, r, l;
    scanf("%d %d", &m, &n);
    int arr[20][20];

    for (i = 0; i < m; i++)
    {
        for (j = 0; j < n; j++)
        {
            scanf("%d", &arr[i][j]);
        }
    }
    int max = arr[0][0];
    for (i = 0; i < m; i++)
    {
        for (j = 0; j < n; j++)
        {
            if (max <= arr[i][j])
            {
                max = arr[i][j];
                r = i;
                l = j;
            }
        }
    }
    printf("Max: %d\nLocation: [%d][%d]", max, r, l);
}