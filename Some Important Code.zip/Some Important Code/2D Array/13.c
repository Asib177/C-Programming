#include <stdio.h>

void main()
{
    int i, j, m, n;
    scanf("%d %d", &m, &n);
    int arr[20][20];

    for (i = 0; i < m; i++)
    {
        for (j = 0; j < n; j++)
        {
            scanf("%d", &arr[i][j]);
        }
    }

    printf("\n");
    for (i = 0; i < m; i++)
    {
        for (j = n - 1; j >= 0; j--)
        {
            printf("%d ", arr[i][j]);
        }
        printf("\n");
    }
}