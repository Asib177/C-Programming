#include <stdio.h>

int main()
{
    FILE *ashfaq = fopen("akash.txt", "w");
    fprintf(ashfaq, "%s", "Good Morning\n");
    int a, b;
    scanf("%d %d", &a, &b);
    int sum = a + b;
    fprintf(ashfaq, "%d\n", sum);

    fclose(ashfaq);

    return 0;
}