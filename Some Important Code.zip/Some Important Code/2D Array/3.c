#include <stdio.h>

void main()
{
    int i, j;

    int arr[20][20];

    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 2; j++)
        {
            scanf("%d", &arr[i][j]);
        }
    }

    int determinant = (arr[0][0] * arr[1][1]) - (arr[0][1] * arr[1][0]);
    printf("%d ", determinant);
}