#include <stdio.h>

void main()
{
    int i, j, n;
    scanf("%d", &n);
    int arr[20][20];

    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            if (i == j)
                printf("1 ");
            else
                printf("0 ");
        }
        printf("\n");
    }
}