#include <stdio.h>

void main()
{
    int i, j, n, m;
    scanf("%d %d", &n, &m);
    int arrA[20][20];

    for (i = 0; i < n; i++)
    {
        for (j = 0; j < m; j++)
        {
            scanf("%d", &arrA[i][j]);
        }
    }

    int arrB[20][20];
    // scanf("%d %d", &n, &m);

    for (i = 0; i < n; i++)
    {
        for (j = 0; j < m; j++)
        {
            scanf("%d", &arrB[i][j]);
        }
    }

    int arrC[20][20];
    // printf("Array C = A+B");
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < m; j++)
        {
            // if (arrA[i][j] == arrB[i][j])
            arrC[i][j] += arrA[i][j] * arrB[j][i];
            printf("%d ", arrC[i][j]);
        }
        printf("\n");
    }
}