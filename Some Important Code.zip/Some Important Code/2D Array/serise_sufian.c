// #include <stdio.h>

// void main()
// {
// int n, i, j, sum = 0;
// scanf("%d", &n);

// for (i = 1, j = 2; i <= n; i++, j++)
// {
//     printf("%dx%d ", i, j);
//     if (i < n)
//         printf("+ ");
//     sum += i * j;
// }
// printf("= %d", sum);
// }
///////////////////////////////////////////////////
//////////////////////////////////////////////////
// #include <stdio.h>

// void main()
// {
//     int n, i = 0, r = 5;
//     scanf("%d", &n);

//     printf("%d", r);
//     while (r < n)
//     {
//         r = r * 2;
//         if (r < n)
//             printf(",%d", r);
//         i++;
//     }
// }

//////////////////////
/////////////////////

#include <stdio.h>
int main()
{
    int i, n;
    scanf("%d", &n);
    for (i = 5; i <= n; i = i * 2)
    {
        printf("%d", i);
        if (i < n - (i))
        {
            printf(",");
        }
        else
        {
            printf(" ");
        }
    }
    return 0;
}