#include <stdio.h>

void main()
{
    int n, i, j;
    scanf("%d", &n);
    int arr[100][100];

    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            scanf("%d", &arr[i][j]);
        }
    }

    for (j = 0; j < n; j++)
    {
        for (i = 0; i < n; i++)
        {
            if (arr[i][j] % 2 == 0)
                printf("%d ", arr[i][j]);
        }
        printf("\n");
    }
}