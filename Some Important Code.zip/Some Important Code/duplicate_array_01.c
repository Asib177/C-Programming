#include <stdio.h>

int main()
{
    int i, j, count = 0;
    int arr[6] = {1, 1, 2, 2, 1, 5};

    for (i = 0; i < 6; i++)
    {
        for (j = i + 1; j < 6; j++)
        {
            if (arr[i] == arr[j])
                count++;
            break;
            ;
        }
    }
    printf("%d ", count);

    return 0;
}