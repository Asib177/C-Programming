#include <stdio.h>

void mainI()
{
    int num1 = 5, num2;
    char chr = 'q';
    scanf("%d", &num2);
    num1 = num2 % chr;
    printf("Result is= %d", num1);
}