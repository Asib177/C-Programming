#include <stdio.h>

void main()
{
    int n, r, sum = 0;
    scanf("%d", &n);

    for (int i = 1; i <= n; i++)
    {
        if (i % 2 == 0)
            printf("-");
        printf("%d", i);
        if (i < n)
            printf(", ");
        sum += i;
    }

    printf("\nResult: %d", sum);
}