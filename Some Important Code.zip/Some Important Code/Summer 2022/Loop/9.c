#include <stdio.h>

void main()
{
    int n, i, r;
    scanf("%d", &n);

    for (i = 1; i <= n; i++)
    {
        r = i * 2;
        if (i % 2 == 0)
            printf("-");
        printf("%d", r);
        if (i < n)
            printf(", ");
    }
}