#include <stdio.h>

void main()
{
    int n, i, r;
    scanf("%d", &n);

    for (i = 1; i <= n; i++)
    {
        r = i * i + i;
        printf("%d", r);
        if (i != n)
            printf(", ");
    }
}