#include <stdio.h>

void main()
{
    int x;
    scanf("%d", &x);

    switch (x)
    {
    case 0:
        printf("2\n");
        break;
    case 2:
        printf("0\n");
        break;
    default:
        printf("3\n");
        break;
    }
    printf("1\n");
}