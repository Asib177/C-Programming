#include <stdio.h>

void main()
{
    int arr[50];
    int n, r;
    scanf("%d", &n);

    for (int i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }
    int max = arr[0];
    for (int i = 0; i < n; i++)
    {
        if (arr[i] >= max)
        {
            max = arr[i];
            r = i;
        }
    }
    printf("Max Arr: %d\nIndex: %d", max, r);
    int min = arr[0];
    for (int i = 0; i < n; i++)
    {
        if (arr[i] <= min)
        {
            min = arr[i];
            r = i;
        }
    }
    printf("\nMin Arr: %d\nIndex: %d", min, r);
}