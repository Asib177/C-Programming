#include <stdio.h>
void main()
{
    int n = 3, i, j, sum = 0;
    // for (i = 0; i < n; i++)
    // {
    //     for (j = 0; j <= i; j++)
    //     {
    //         if (i == j)
    //             sum += i + j;
    //         else if (i > j)
    //             sum += i + n;
    //         else
    //             sum += n - j;
    //     }
    // }

    i = 0;
    do
    {
        printf("%d ", sum);
        do
        {
            printf("%d ", sum);
            if (i == j)
                sum += i + j;
            else if (i > j)
                sum += i + n;
            else
                sum += n - j;
            j++;
        } while (j <= i);
        i++;

    } while (i < n);

    printf("%d ", sum);
}
