#include <stdio.h>
void main()
{
    // float a = 5 * (5 / 2);
    // int b = 5 * (5 / 2);
    // float c = 5 * (5.0 / 2);
    // int d = 5 * (5.0 / 2);

    // int a = 10.0 / 3 * 10;
    // float b = (int)23.0 % 11;
    // int c = (10 > 9 && 21 <= 19) * 5;
    // float d = 7 / 2;

    // int F[6] = {0};
    // int i, n;
    // n = 3;
    // for (i = 0; i < 6; i++)
    // {
    //     F[i] = n + i;
    //     if (F[i] % 2 == 0)
    //     {
    //         F[i] *= 2;
    //         printf("%d ", F[i]);
    //     }
    // }

    // printf("%d\n%f\n%d\n%f", a, b, c, d);
    int x;
    scanf("%d", &x);
    switch (x)
    {
    case 0:
        printf("Good");
        break;
    case 3:
        printf("Morning");
    case 7:
        printf("Hello");
        break;
    case 11:
        printf("World");
    case 17:
        printf("Best");
        break;
    case 21:
        printf("Wishes !");
    default:
        printf("Invalid answer");
    }
}
