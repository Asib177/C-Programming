#include <stdio.h>
int main()
{
    int a, b;
    float sum;
    scanf("%d %d", a, b);
    sum += a;
    print("%d", sum);
    return 0;
}
