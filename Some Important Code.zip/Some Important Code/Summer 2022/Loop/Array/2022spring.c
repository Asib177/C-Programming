#include <stdio.h>
#include <math.H>
int main()
{
    float n_, m = 5;
    scanf("%f", &n_);
    float p = ((int)n_ % (int)m) / sqrt(6);
    printf("%f", p);
}