#include <stdio.h>

void main()
{
    float arr[50], sum = 0, avg;
    int n;
    scanf("%d", &n);

    for (int i = 0; i < n; i++)
    {
        scanf("%f", &arr[i]);
    }
    for (int i = 0; i < n; i++)
    {
        sum += arr[i];
    }
    avg = sum / n;
    printf("Average: %.2f ", avg);
}