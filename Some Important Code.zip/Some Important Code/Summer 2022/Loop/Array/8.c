#include <stdio.h>

void main()
{
    int arr[50];
    int n, r, p;
    scanf("%d", &n);

    for (int i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }

    scanf("%d", &r);
    // int r = arr[0];
    for (int i = 0; i < n; i++)
    {
        if (r == arr[i])
        {
            p = i;
            printf("FOUND at index position: %d", p);
            break;
        }
        else
            printf("NOT FOUND");
    }
}
