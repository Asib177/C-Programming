#include <stdio.h>

void main()
{
    int arr[50];
    int n;
    scanf("%d", &n);

    for (int i = 1; i <= n; i++)
    {
        scanf("%d", &arr[i]);
    }
    // for (int i = n; i >=1; i--)
    // {
    //     printf("%d ", arr[i]);
    // }
}