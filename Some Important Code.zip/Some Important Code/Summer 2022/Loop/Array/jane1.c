#include <stdio.h>

int main()
{
    int n, m, i, j;
    scanf("%d", &n);
    int arrA[50];
    for (i = 0; i < n; i++)
    {
        scanf("%d", &arrA[i]);
    }

    scanf("%d", &n);
    int arrB[50];
    for (j = 0; j < n; j++)
    {
        scanf("%d", &arrB[j]);
    }

    int arr3[100];
    for (int k = 0; k < i; k++)
    {
        arr3[k] = arrA[k];
        printf("%d ", arr3[k]);
    }
    for (int k = 0; k < j; k++)
    {
        arr3[k] = arrB[k];
        printf("%d ", arr3[k]);
    }

    return 0;
}