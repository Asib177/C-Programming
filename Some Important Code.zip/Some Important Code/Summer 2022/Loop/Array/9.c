#include <stdio.h>

void main()
{
    int arr[50], arr1[50];
    int n;
    scanf("%d", &n);

    for (int i = 1; i <= n; i++)
    {
        scanf("%d", &arr[i]);
    }
    printf("Array A:");

    for (int i = 1; i <= n; i++)
    {
        printf("%d ", arr[i]);
    }

    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            arr1[j] = arr[i];
        }
    }
    printf("\nArray B:");
    for (int j = n; j >= 1; j--)
    {
        printf(" %d", arr[j]);
    }
}