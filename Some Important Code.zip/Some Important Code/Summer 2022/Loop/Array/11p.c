#include <stdio.h>

void main()
{
    int arr1[50], arr2[50];
    int n, m, i, j;
    scanf("%d %d", &n, &m);

    for (i = 0; i < n; i++)
    {
        scanf("%d", &arr1[i]);
    }

    for (j = 0; j < m; j++)
    {
        scanf("%d", &arr2[j]);
    }

    int temp;
    printf("Array A: ");
    for (i = 0; i < m; i++)
    {
        temp = arr1[i];
        arr1[i] = arr2[j];
        arr2[j] = temp;
        printf("%d ", temp);
    }
    // printf("Array B: ");
    // for (j = 0; j < n; j++)
    // {
    //     arr2[j] = arr1[i];
    //     printf("%d ", arr2[j]);
    // }
}