#include <stdio.h>

void main()
{
    int a = 10, b = 2;
    printf("%d", a + b);
}