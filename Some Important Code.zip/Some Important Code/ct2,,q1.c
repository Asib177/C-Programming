#include <stdio.h>

void main()
{
    int n, m;
    printf("Enter the row number: ");
    scanf("%d", &n);

    m = n;
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= m - 1; j++)
        {
            printf("_");
        }

        for (int k = 1; k <= 2 * i - 1; k++)
        {
            if (k == 1 || k == 2 * i - 1 || i == n)
            {
                printf("*");
            }
            else
                printf("_");
        }
        m--;
        printf("\n");
    }
    printf("%d", m);
}