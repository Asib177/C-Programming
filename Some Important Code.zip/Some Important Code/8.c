#include <stdio.h>

int main()
{
    int a = 1, b = 2, c = 3, d = 4;
    int ans;

    ans = a * b / c;
    printf("%d", ans);

    ans = a * b % c + 1;
    printf("\n%d", ans);

    ans = ++a * b % c--;
    printf("\n%d", ans);

    ans = 7 - -b * ++d;
    printf("\n%d", ans);

    return 0;
}