#include <stdio.h>

int main()
{
    int n, i, r;
    scanf("%d", &n);

    for (i = 1; i <= n; i++)
    {
        r = i + ((4 + i - 1) * i);
        printf("%d ", r);
        if (i < n)
        {
            printf("+ ");
        }
    }

    return 0;
}