#include <stdio.h>

void swaping(int *ptr1, int *ptr2)
{
    int temp;
    temp = *ptr1;
    *ptr1 = *ptr2;
    *ptr2 = temp;
}

void main()
{
    int x, y;
    scanf("%d %d", &x, &y);

    printf("\nBefore swaping:\nX is = %d\nY is = %d", x, y);
    swaping(&x, &y);
    printf("\n\nAfter swaping:\nX is = %d\nY is = %d", x, y);
}