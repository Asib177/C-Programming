#include <stdio.h>

void swap(int *a, int *b)
{
    printf("\nAddress of a = %d | Value of a = %d", &a, a);
    printf("\nAddress of b = %d | Value of b = %d", &b, b);

    int temp;
    temp = *a;
    *a = *b;
    *b = temp;
}

void main()
{
    int n, m;
    scanf("%d %d", &n, &m);
    printf("Address of n = %d | Value of n = %d", &n, n);
    printf("\nAddress of m = %d | Value of m = %d", &m, m);

    swap(&n, &m);
    printf("\nAddress of n = %d | Value of n = %d", &n, n);
    printf("\nAddress of m = %d | Value of m = %d", &m, m);
}
