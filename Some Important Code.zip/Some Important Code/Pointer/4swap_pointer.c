#include <stdio.h>

void main()
{
    int x, y, temp;
    printf("Enter x & y value: ");
    scanf("%d %d", &x, &y);

    int *ptr1, *ptr2;
    ptr1 = &x, ptr2 = &y;

    temp = *ptr1;
    *ptr1 = *ptr2;
    *ptr2 = temp;

    printf("X is: %d\n", *ptr1);
    printf("Y is: %d", *ptr2);
}