#include <stdio.h>

void main()
{
    int x = 5, y = 10, z = 15;
    int *ptr;

    ptr = &x;
    printf("X = %d\n", *ptr);

    ptr = &y;
    printf("Y = %d\n", *ptr);

    ptr = &z;
    printf("Z = %d\n", *ptr);
}