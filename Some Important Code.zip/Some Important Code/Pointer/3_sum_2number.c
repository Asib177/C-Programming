#include <stdio.h>

void main()
{
    int x, y, sum;
    scanf("%d %d", &x, &y);

    int *ptr1, *ptr2;

    // ptr1 = &x, ptr2 = &y;
    ptr1 = &x;
    ptr2 = &y;

    sum = *ptr1 + *ptr2;
    printf("Sum is: %d", sum);
}