#include <stdio.h>

int main()
{
    FILE *file;
    file = fopen("text.txt", "w");
    if (file == NULL)
    {
        printf("Fine not exist.");
    }

    else
    {
        printf("File successfully Open.");
        fclose(file);
    }

    return 0;
}