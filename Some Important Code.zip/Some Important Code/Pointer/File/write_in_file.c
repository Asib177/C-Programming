#include <stdio.h>

int main()
{
    char name[50] = "Rakibul Asib";
    int length = strlen(name);

    FILE *file;
    file = fopen("text1.txt", "w");
    if (file == NULL)
    {
        printf("Fine not exist.");
    }

    else
    {
        printf("File successfully Open.\n");
        for (int i = 0; i < length; i++)
        {
            fputc(name[i], file);
        }
        printf("File write successfully.");
        fclose(file);
    }

    return 0;
}