#include <stdio.h>

int main()
{
    FILE *file;
    file = fopen("new.txt", "a");
    char name[50];

    if (file == NULL)
    {
        printf("File doesn't open.\n");
    }
    else
    {
        printf("File is open.\n");
        printf("Enter your full name: ");
        gets(name);

        fputs(name, file);
        fputs("\n", file);
        fclose(file);
    }

    return 0;
}