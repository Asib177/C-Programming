#include <stdio.h>
void main()
{
    int n, arr[50];
    scanf("%d", &n);
    int *ptr, i;

    for (i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }

    ptr = &arr[0];
    for (i = 0; i < n; i++)
    {
        printf("%d ", *ptr);
        ptr++;
    }
}