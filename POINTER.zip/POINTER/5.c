#include <stdio.h>

int *multiplier1(int arr[], int size)
{
    for (int i = 0; i <size; i++)
    {
        arr[i] = arr[i] * 2;
    }
    return arr;
}
#define globalsize 5
int *multiplier2(int arr[], int size)
{
    
    static int newArray[globalsize];
    for (int i = 0; i <globalsize; i++)
    {
        newArray[i] = arr[i] * 2;
    }

    // for (int i = 0; i <size; i++)
    // {
    //     printf("%d ",newArray[i]);
    // }
    static int hello = 10;
    static int *ptr;
    ptr = &hello;
    return ptr;
}




int main()
{

    int n;
    scanf("%d", &n);
    int array[n];
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &array[i]);
    }

    printf("Original Array :");
    for (int i = 0; i < n; i++)
    {
        printf("%d ", array[i]);
    }
    printf("\nMultiplied Array: ");
    int *p;
    p = multiplier2(array, n);
    printf("%d is the value of hello", *p);
    // for (int i = 0; i < n; i++)
    // {
    //     printf("%d ", *p);
    //     p++;
    // }

    // printReverse2(array, n);
    // for(int i =n-1; i>=0; i--){
    //     printf("%d ",array[i]);
    // }

    return 0;
}