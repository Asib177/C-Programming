#include <stdio.h>

int main()
{
    int range1, range2;

    scanf("%d", &range1);
    scanf("%d", &range2);

    for (int i = range1; i <= range2; i++)
    {
        if (sectumSempra(i) == 1)
            printf("%d ", i);
    }

    return 0;
}

int sectumSempra(int a)
{

    int cF1 = checkerFunction1(a);
    int cF2 = checkerFunction2(a);
    int cF3 = checkerFunction3(a);
    int cF4 = checkerFunction4(a);

    if (cF1 == 1 && cF2 == 1 && cF3 == 1 && cF4 == 1)
        return 1;
    else
        return -1;
}

int checkerFunction1(int a)
{
    int x;
    x = a;
    int ld, fd;
    int rem = 0;
    while (x != 0)
    {
        rem = x % 10;

        if (x == a)
            ld = rem;

        x /= 10;

        if (x == 0)
            fd = rem;
    }

    if ((fd == 7 || fd == 1) && (ld != 9 || ld != 2))
    {

        return 1;
    }
    else
        return -1;
}

int checkerFunction2(int a)
{
    int x;
    x = a;
    int rem = 0;
    int count = 0;
    int mc = 0;
    while (x != 0)
    {
        rem = x % 10;
        count++;
        x /= 10;
    }

    mc = count;

    x = a;
    while (x != 0)
    {
        rem = x % 10;
        if (((mc % 2 == 0 && rem % 2 != 0) || (mc % 2 != 0 && rem % 2 == 0)) == 0)
            return -1;
        mc--;
        x /= 10;
    }

    return 1;
}
int checkerFunction3(int a)
{

    int isStrong = strongChecker(a);
    int isDefective = defectiveChecker(a);

    if (isStrong == 1 && isDefective == -1)
        return 1;
    else
        return -1;
}
int checkerFunction4(int a)
{
    int x;
    x = a;
    int rem = 0;
    int count = 0;

    while (x != 0)
    {
        rem = x % 10;
        count++;
        x /= 10;
    }

    if (count >= 2)
    {

        x = a;
        int sum = 0;
        while (x != 0)
        {
            rem = x % 10;

            sum += rem * rem;

            x /= 10;
        }

        if (sum % 7 == 0)
        {
            return 1;
        }
        else
        {
            return -1;
        }
    }
    else
        return -1;
}

int strongChecker(int a)
{
    int x = a, sum = 0;

    while (x != 0)
    {
        int digit = x % 10;
        int fac = 1;
        for (int i = digit; i >= 1; i--)
        {
            fac *= i;
        }
        sum += fac;
        x /= 10;
    }

    if (sum == a)
        return 1;
    else
        return -1;
}

int defectiveChecker(int a)
{

    int sum = 0;

    for (int i = 1; i <= a; i++)
    {
        if (a % i == 0)
            sum += i;
    }

    if (sum < (2 * a))
        return 1;
    else
        return -1;
}