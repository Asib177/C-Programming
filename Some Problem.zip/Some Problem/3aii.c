#include <stdio.h>

int main()
{
    int n;
    scanf("%d", &n);

    int flag = countDigit(n);
    printf("%d", flag);

    return 0;
}