#include <stdio.h>

int func();
int search();

typedef struct student
{
    char name[100];
    int ID;
    char status[100];
} STD;

int main()
{
    func();
    search();

    return 0;
}

int func()
{
    STD s;
    FILE *fp;
    fp = fopen("student.txt", "a+");

    printf("\nEnter student name: ");
    gets(s.name);
    printf("Enter student ID: ");
    scanf("%d", &s.ID);
    fflush(stdin);
    printf("Enter Status: ");
    gets(s.status);

    fwrite(&s, sizeof(s), 1, fp);

    printf("Information stored successfully.");

    fclose(fp);
}

int search()
{
    char name[100];
    STD s;

    int flag = 0;
    FILE *fp;
    fp = fopen("student.txt", "rb");

    printf("\n\nPlease write the name of the person you want to know about: ");
    scanf("%s", &name);

    while (fread(&s, sizeof(s), 1, fp) > 0 && flag == 0)
    {
        if (s.name == name)
        {
            flag = 0;
            printf("\nSearch Result: \n");
            printf("Name: %s\n", s.name);
            printf("ID: %d", s.ID);
            printf("Status: %s", s.status);
        }
    }

    fclose(fp);
}