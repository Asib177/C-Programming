#include<stdio.h>
#include<string.h>

typedef struct worker
{
	char name[10];
	int id;
	int sal;
}wk;

int main()
{
	wk a[3];
	int i, n;
	scanf("%d", &n);

	for (i = 0; i < n; i++)
	{
		scanf("%s", a[i].name);
	}
	for (i = 0; i < n; i++)
	{
		scanf("%d", &a[i].id);
	}
	for (i = 0; i < n; i++)
	{
		scanf("%d", &a[i].sal);
	}

	printf("Information Stored Successfully.\nPlease write the name of the person you want to know about : ");

	char sr[10];
	scanf("%s", sr);

	for (i = 0; i < n; i++)
	{
		if (strstr(a[i].name, sr) != 0)
		{
			break;
		}
	}

	printf("\nSearch  Result:\n\n");
	printf("Name: %s\n", a[i].name);
	printf("ID: %d\n", a[i].id);
	if (a[i].sal > 16000)printf("Status: A");
	else printf("Status: B");

	return 0;

}