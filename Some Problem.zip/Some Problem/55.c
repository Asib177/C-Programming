#include<stdio.h>
void insert_record();
void search_record();

struct person
{
    char name[50];
    int ID;
    char status[50];
};

struct person s;


int main()
{
    return 0;
}

void insert_record()
{
    FILE *fp;

    fp = fopen("stu.txt", "ab+");

    if (fp == NULL)
    {
        printf("\n\tError: Can't open the file!");
        return;
    }

    printf("\n\n\tPrevious Stored Data!!!");
    display_record();

    printf("\n\n\tEnter new student data!!");
   
    fflush(stdin);
    printf("\t\tEnter student name: ");
    gets(s.name);
    printf("\t\tEnter Section name: ");
    gets(s.status);
    printf("\t\tEnter student total marks: ");
    scanf("%d", &s.ID);
    fwrite(&s, sizeof(s), 1, fp);

    printf("\n\n\t\tStudent record inseart successfully!!!");

    fclose(fp);
}

void search_record()
{
    int  flag = 0;
    char name[50];
    FILE *fp;
    fp = fopen("stu.txt", "rb");

    if (fp == NULL)
    {
        printf("Error: Can't open the file.");
        return;
    }

    printf("Enter student roll number which you want to search: ");
    scanf("%c", &name);

    while (fread(&s, sizeof(s), 1, fp) > 0 && flag == 0)
    {
        if (s.name == name)
        {
            flag = 1;
            printf("\n\n\tSearch successfully and student record is as follow: \n\n");
            printf("\nRoll Number \tName of students \tsection \tmarks \tCGPA\n\n");
            printf("\t%d \t%s \t%s \t%d \t%.2f", s.roll, s.name, s.sec, s.marks, s.cgpa);
        }
    }
    if (flag == 0)
    {
        printf("\n\tNo search record fond.");
    }
    fclose(fp);
}