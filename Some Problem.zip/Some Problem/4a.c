#include<stdio.h>
#include<string.h>


int main()
{
	int a[100], sum=0;

	FILE* fp = fopen("O://C_Codes//All about Files//Files//Sample.txt", "r");
	int i;


	for (i = 0; !feof(fp); i++)
	{
		fscanf(fp, "%d", &a[i]);

		fgetc(fp);
		sum = sum + a[i];
	}
	printf("avg = %.2f", (float)sum/i);

    return 0;
	
}