#include <stdio.h>

int countDigit(int a)
{
    int count = 0;
    int temp = a;

    while (temp != 0)
    {
        int r = temp / 10;
        count++;
        temp = r;
    }
    return count;
}