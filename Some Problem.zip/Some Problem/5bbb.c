#include <stdio.h>
#include <string.h>

typedef struct people
{
	char name[10];
	int ID;
	int status;
} P1;

int main()
{
	P1 arr[100];
	int n;
	int i;
	scanf("%d", &n);

	for (i = 0; i < n; i++)

		scanf("%s %d %d", &arr[i].name, &arr[i].ID, &arr[i].status);

	printf("Information Stored Successfully.");
	printf("\nPlease write the name of the person you want to know about : ");
	char pub[100];
	scanf("%s", pub);

	for (i = 0; i < n; i++)
	{
		if (strstr(arr[i].name, pub) != 0)
		{
			break;
		}
	}

	printf("\nSearch  Result: ");
	printf("\n\nName: %s", arr[i].name);
	printf("\nID: %d", arr[i].ID);
	if (arr[i].status > 16000)
		printf("\nStatus: A");
	else
		printf("\nStatus: B");

	return 0;
}