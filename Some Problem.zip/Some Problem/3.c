#include <stdio.h>

int main()
{
    int n;
    scanf("%d", &n);

    int flag = countDigit(n);
    printf("%d", flag);

    return 0;
}

int countDigit(int a)
{
    int count = 0;
    int temp = a;

    while (temp != 0)
    {
        int r = temp / 10;
        count++;
        temp = r;
    }
    return count;
}