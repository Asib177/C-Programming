#include <stdio.h>

int main()
{
    int n;
    int arr[100][100];
    scanf("%d", &n);

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            scanf("%d", &arr[i][j]);
        }
    }
    int flag = 0;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (j < i)
            {
                if (arr[i][j] == 0)
                {
                    flag = 1;
                }
                else
                {
                    flag = 0;
                    break;
                }
            }
        }
    }

    if (flag == 1)
    {
        int r = 1;
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                if (i == j)
                {
                    r = r * arr[i][j];
                }
            }
        }
        printf("%d", r);
    }

    else if (flag == 0)
    {
        int a = 0;
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                if (i == j)
                {
                    a = a + arr[i][j];
                }
            }
        }
        printf("%d", a);
    }

    return 0;
}