#include <stdio.h>

int main()
{
    FILE *fp;
    fp = fopen("Sample.txt", "r");
    int i = 0, sum = 0;
    int n;
    while (!feof(fp))
    {
        i++;
        fscanf(fp, "%d", &n);

        sum += n;
    }

    printf("%d", sum / i);
    fclose(fp);
    return 0;
}