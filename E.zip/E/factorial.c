#include <stdio.h>
// 5
// 5! = 5 X 4 X 3 X 2 X 1 = 120
// 3
// 3 2 1
int main()
{
    // int n;
    // scanf("%d",&n);
    int r1, r2;
    scanf("%d %d", &r1, &r2);

    for (int k = r1; k <= r2; k++)
    {
        if (k % 2 != 0)
        {
            break;
        }
        printf("%d ! = ", k);
        int fac = 1;
        for (int i = k; i >= 1; i--)
        {
            // 5 4 3 2 1 ---> i
            printf("%d", i);
            if (i > 1)
                printf(" X ");
            fac *= i;
        }

        printf(" = %d\n", fac);
    }

    return 0;
}

// int i = n;
// while(i>=1){
//     printf("%d",i);
//     if(i>1) printf(" X ");
//     fac *= i;
//     i--;
// }

// int i =n;
// do{
//     printf("%d",i);
//     if(i>1) printf(" X ");
//     fac *= i;
//     i--;
// }while(i>=1);
