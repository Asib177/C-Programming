#include <stdio.h>

int main()
{
    int n;
    scanf("%d",&n);
    int array[n];

    int i = n;
    int j = 0;
    while(i>0){
        int rem = i % 10;
        array[j]=rem;
        j++;
        printf("%d\n",rem);
        i = i/10;
    }

    int l = 1;
    for(int i =j-1; i>=0; i--){
        printf("\nNo %d position is %d\n",l, array[i]);
        l++;
    }

    return 0;
}
