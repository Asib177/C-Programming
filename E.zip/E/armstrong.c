#include <stdio.h>
#include <math.h>
int main()
{
    int n;
    scanf("%d",&n);
    int sum=0;
    int i = n;
    while(i>0){
        int rem = i % 10;
        sum += pow(rem,3);
        // printf("%d\n",rem);
        i = i/10;
    }

    if(sum==n) printf("Armstrong");
    else printf("Not");

    return 0;
}
