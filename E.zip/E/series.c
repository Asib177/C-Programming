#include <stdio.h>

// 8 = 1*2 + 3*4 + .....

int main()
{
    int n;
    scanf("%d", &n);
    int mul = 0;
    int total = 0;
    for (int i = 1; i <= n; i++)
    {
        printf(" %d ", i);
        if (i % 2 != 0)
        {
            total += mul;
            mul = 1;
        }
        
        
        
        if (i % 2 != 0)
        {
            if (i != n)
                printf(" X ");
            mul *= i;
        }
        else
        {
            if (i != n)
                printf(" + ");
            mul *= i;
            //printf("%d\n", mul); // Array-->
        }
    }

    printf(" = %d",total + mul);

    return 0;
}