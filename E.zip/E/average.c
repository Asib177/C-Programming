// 5
// 12 13 1 12 1
// Average: 7.67

// 3
// 2 4 5
// Average: 4.56

#include<stdio.h>

int main(){

    // user input size
    int n;
    scanf("%d",&n);
    int array[n];
    float sum = 0;
    int min = __INT_MAX__;
    int min_index;

    for(int i =0; i<n;i++){
        scanf("%d",&array[i]);
        if(array[i]<min){
            min = array[i];
            min_index=i;
        }
    }

    for (int i = 0; i < n; i++)
    {
        printf(" %d ",array[i]);
    }

    printf("\nMinimum Number in the Array is %d\n", min);
    printf("Minimum Number is at Position %d in the array", min_index+1);
    // for(int i =2; i<n+2;i++){
    //     int temp;
    //     scanf("%d",&temp);
    //     sum += temp;
    // }

    // printf("Average : %f", sum/n);
    // sum = 0;
    // Loop
    //     value input

    return 0;
}