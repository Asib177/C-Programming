#include <stdio.h>

typedef struct person
{
    char name[40];
    char fname[40];
    int age;
    float CGPA;
} PERSON;

int main()
{
    int n;
    scanf("%d", &n);
    getchar();
    PERSON people[n];

    for (int i = 0; i < n; i++)
    {

        printf("Enter the value of person %d: \n", i + 1);
        printf("Name: ");
        gets(people[i].name);

        printf("Age: ");
        scanf("%d", &people[i].age);

        printf("CGPA: ");
        scanf("%f", &people[i].CGPA);
        getchar();

        printf("Father name: ");
        gets(people[i].fname);
    }

    for (int i = 0; i < n; i++)
    {
        printf("\nPerson No. %d", i + 1);
        printf("\nName: %s", people[i].name);
        printf("\nFather name: %s", people[i].fname);
        printf("\nAge: %d", people[i].age);
        printf("\nCGPA: %.3f", people[i].CGPA);
        printf("\n");
    }

    return 0;
}