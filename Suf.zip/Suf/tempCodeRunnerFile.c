
    printf("Sum is: %d", sum);